// pages/logs/index.js
//var WxSearch = require('../../wxSearch/wxSearch.js')
var app = getApp()


Page({

  /**
   * 页面的初始数据
   */
  data: {
    focus: false,
    loadingMoreHidden: true,
    inputValue: '',
    swiperImage:[{
      image: './image/food1.jpg'
      },
      {
        image: './image/food2.jpg'
      },
      {
        image: './image/food3.jpg'
      },
      {
        image: './image/food4.jpg'
      }
    ],
    imageArray: [{
        image: './icon/yilou.png',
        name: '食堂一楼'
      },
      {
        image: './icon/erlou.png',
        name: '食堂二楼'
      },
      {
        image: './icon/yilou.png',
        name: '鼓瑟轩'
      },
      {
        image: './icon/yilou.png',
        name: '鹿鸣轩'
      },
      {
        image: './icon/qingzhen.png',
        name: '清真食堂'
      }
    ],

    imageArray2: [{
        image: './icon/zaocan.png',
        name: '早餐'
      },
      {
        image: './icon/wode-.png',
        name: '午餐'
      },
      {
        image: './icon/wancan.png',
        name: '晚餐'
      },
      {
        image: './icon/roulei.png',
        name: '肉类'
      },
      {
        image: './icon/shucailei.png',
        name: '蔬菜类'
      }
    ],
    food_message: [
      {
        pic: './image/food1.jpg',
        name: '食物名称', 
        price: '6.00',
        place: '食堂一楼南侧' 
      },
      { 
        pic: './image/food2.jpg',
        name: '食物名称', 
        price: '6.00', 
        place: '食堂一楼南侧' 
      },
      { 
        pic: './image/food3.jpg', 
        name: '食物名称', 
        price: '6.00', 
        place: '食堂一楼南侧' 
      },
      { 
        pic: './image/food4.jpg', 
        name: '食物名称', 
        price: '6.00', 
        place: '食堂一楼南侧' 
      },
      { 
        pic: './image/food2.jpg', 
        name: '食物名称', 
        price: '6.00', 
        place: '食堂一楼南侧' 
      },
      { 
        pic: './image/food1.jpg', 
        name: '食物名称', 
        price: '6.00', 
        place: '食堂一楼南侧' 
      },
      { 
        pic: './image/food4.jpg', 
        name: '食物名称', 
        price: '6.00', 
        place: '食堂一楼南侧' 
      },
      { 
        pic: './image/food3.jpg', 
        name: '食物名称', 
        price: '6.00', 
        place: '食堂一楼南侧'
      },
      { 
        pic: './image/food1.jpg', 
        name: '食物名称', 
        price: '6.00', 
        place: '食堂一楼南侧' 
      },
      { 
        pic: './image/food1.jpg', 
        name: '食物名称', 
        price: '6.00', 
        place: '食堂一楼南侧' 
      },
    ]
  },


  searchFocus: function() {
    wx.navigateTo({
      url: '/pages/search/search',
    })
  },

  go: function() {
    wx.navigateTo({
      url: '/pages/detail/detail',
    })
  },
  bindKeyInput: function(e) {
    this.setData({
      inputValue: e.detail.value
    })
  },
  bindReplaceInput: function(e) {
    var value = e.detail.value
    var pos = e.detail.cursor
    var left
    if (pos !== -1) {
      // 光标在中间
      left = e.detail.value.slice(0, pos)
      // 计算光标的位置
      pos = left.replace(/11/g, '2').length
    }

    // 直接返回对象，可以对输入进行过滤处理，同时可以控制光标的位置
    return {
      value: value.replace(/11/g, '2'),
      cursor: pos
    }

    // 或者直接返回字符串,光标在最后边
    // return value.replace(/11/g,'2'),
  },
  bindHideKeyboard: function(e) {
    if (e.detail.value === '123') {
      // 收起键盘
      wx.hideKeyboard()
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {
        console.log('[云函数] [login] user openid: ', res.result.openid)
        app.globalData.openid = res.result.openid
      },
      fail: err => {
        console.error('[云函数] [login] 调用失败', err)
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },

})